<?php
return array (
  'New message' => 'Uusi viesti',
  'Send message' => 'Viesti',
);
