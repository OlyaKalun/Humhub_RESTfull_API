<?php
return array (
  'Add recipients' => 'Címzettek',
  'New message' => 'Új üzenet',
  'Send' => 'Küldés',
);
