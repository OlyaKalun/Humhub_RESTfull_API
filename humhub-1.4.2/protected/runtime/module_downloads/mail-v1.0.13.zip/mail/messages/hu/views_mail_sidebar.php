<?php
return array (
  'Groups' => 'Csoportok',
  'Members' => 'Tagok',
  'Spaces' => 'Közösségek',
  'User Posts' => 'Felhasználó bejegyzések',
);
