<?php
return array (
  'Add more participants to your conversation...' => 'További résztvevők hozzáadása a beszélgetéshez...',
);
