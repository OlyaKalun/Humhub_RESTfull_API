<?php

return [
    'Add more participants to your conversation...' => 'Füge der Unterhaltung weitere Empfänger hinzu...',
];
