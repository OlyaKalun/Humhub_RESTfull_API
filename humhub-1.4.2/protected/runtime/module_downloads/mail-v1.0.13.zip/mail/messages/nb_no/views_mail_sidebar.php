<?php
return array (
  'Groups' => 'Grupper',
  'Members' => 'Medlemmer',
  'Spaces' => 'Grupper',
  'User Posts' => 'Bruker Innlegg',
);
