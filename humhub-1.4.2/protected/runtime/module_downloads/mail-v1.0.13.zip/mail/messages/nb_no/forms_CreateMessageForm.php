<?php
return array (
  'Message' => 'Melding',
  'Recipient' => 'Mottaker',
  'Subject' => 'Tittel',
  'You cannot send a email to yourself!' => 'Du kan ikke sende en e-mai til deg selv!l',
);
