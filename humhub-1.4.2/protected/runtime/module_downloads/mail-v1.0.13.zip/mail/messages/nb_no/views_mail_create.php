<?php

return [
    'Add recipients' => 'Legg til mottakere',
    'New message' => 'Ny melding',
    'Send' => 'Send',
];
