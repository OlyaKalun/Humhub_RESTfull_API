<?php
return array (
  'Message' => 'Mesaj',
  'Recipient' => 'Alıcı',
  'Subject' => 'Konu',
  'You cannot send a email to yourself!' => 'Kendinize e-posta gönderemessiniz!',
);
