<?php
return array (
  'Message' => 'Mesaj',
);
