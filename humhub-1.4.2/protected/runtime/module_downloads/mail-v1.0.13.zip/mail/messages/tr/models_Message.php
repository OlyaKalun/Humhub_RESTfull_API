<?php
return array (
  'New message from {senderName}' => 'Yeni mesaj var. Gönderen {senderName}',
  'and {counter} other users' => 've {counter} diğer kullanıcılar',
);
