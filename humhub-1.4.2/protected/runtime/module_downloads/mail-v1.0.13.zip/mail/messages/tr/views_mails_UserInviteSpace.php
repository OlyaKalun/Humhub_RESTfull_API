<?php
return array (
  'Sign up now' => 'Şimdi kayıt ol',
);
