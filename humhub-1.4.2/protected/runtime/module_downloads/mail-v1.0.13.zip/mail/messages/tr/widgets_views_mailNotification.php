<?php
return array (
  'Messages' => 'Mesajlar',
  'New message' => 'Yeni mesaj',
  'Show all messages' => 'Tüm mesajları göster',
);
