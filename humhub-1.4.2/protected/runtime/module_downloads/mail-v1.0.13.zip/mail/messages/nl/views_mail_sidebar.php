<?php
return array (
  'Groups' => 'Groepen',
  'Members' => 'Leden',
  'Spaces' => 'Spaces',
  'User Posts' => 'Gebruikersberichten',
);
