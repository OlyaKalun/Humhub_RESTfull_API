<?php
return array (
  'There are no messages yet.' => 'Encara no i hai mensaches.',
);
