<?php
return array (
  'New message' => 'Nova poruka',
  'Send message' => 'Pošalji poruku',
);
