<?php
return array (
  'Edit message entry' => '',
  'Save' => '',
);
