<?php

return [
    'Conversations' => 'Sarunas',
    'New' => 'Jauns',
    'There are no messages yet.' => 'Šeit vēl nav nevienas ziņas.',
];
