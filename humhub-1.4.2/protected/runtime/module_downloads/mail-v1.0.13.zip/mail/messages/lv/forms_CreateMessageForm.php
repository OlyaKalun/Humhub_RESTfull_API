<?php
return array (
  'Message' => 'Ziņojums',
  'Recipient' => 'Saņēmējs',
  'Subject' => 'Tēma',
  'You cannot send a email to yourself!' => 'Tu nevari nosūtīt ziņojumu sev pašam!',
);
