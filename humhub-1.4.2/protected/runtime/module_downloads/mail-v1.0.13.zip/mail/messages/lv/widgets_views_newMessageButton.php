<?php
return array (
  'New message' => 'Jauna ziņa',
  'Send message' => 'Sūtīt ziņojumu',
);
