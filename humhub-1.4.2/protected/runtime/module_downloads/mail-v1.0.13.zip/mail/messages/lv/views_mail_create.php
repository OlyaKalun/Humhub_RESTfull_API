<?php

return [
    'Add recipients' => 'Pievieno saņēmējus',
    'New message' => 'Jauna ziņa',
    'Send' => 'Sūtīt',
];
