<?php

return [
    'Add more participants to your conversation...' => 'Pievieno vairāk dalībniekus savai sarunai...',
];
