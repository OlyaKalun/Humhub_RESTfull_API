<?php
return array (
  'There are no messages yet.' => 'Šeit vēl nav nevienas ziņas.',
);
