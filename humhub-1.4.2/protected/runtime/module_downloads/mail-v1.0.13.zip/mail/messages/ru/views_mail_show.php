<?php
return array (
  '<strong>Confirm</strong> deleting conversation' => '<strong>Подтвердите</strong> удаление переписки',
  '<strong>Confirm</strong> leaving conversation' => '<strong>Подтвердите</strong> выход из переписки',
  '<strong>Confirm</strong> message deletion' => '<strong>Подтвердите</strong> удаление сообщения',
  'Add user' => 'Добавить пользователя',
  'Cancel' => 'Отменить',
  'Delete' => 'Удалить',
  'Delete conversation' => 'Удалить диалог',
  'Do you really want to delete this conversation?' => 'Вы действительно хотите удалить эту переписку?',
  'Do you really want to delete this message?' => 'Вы действительно хотите удалить это сообщение?',
  'Do you really want to leave this conversation?' => 'Вы действительно хотите покинуть эту переписку?',
  'Leave' => 'Покинуть',
  'Leave conversation' => 'Создать диалог',
  'Send' => 'Отправить',
  'There are no messages yet.' => 'Здесь пока нет сообщений.',
);
