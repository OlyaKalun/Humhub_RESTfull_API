<?php
return array (
  '<strong>New</strong> message' => '<strong>Новое</strong> сообщение',
  'Reply now' => 'Ответить сейчас',
  'sent you a new message:' => 'отправил вам новое сообщение:',
);
