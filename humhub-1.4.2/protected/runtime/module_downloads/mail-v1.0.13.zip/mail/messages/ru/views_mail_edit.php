<?php

return [
    'Edit message entry' => 'Редактирование сообщения',
];
