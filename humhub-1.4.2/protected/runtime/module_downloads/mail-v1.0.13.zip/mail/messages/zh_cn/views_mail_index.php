<?php

return [
    'Conversations' => '对话',
    'New' => '新的',
    'There are no messages yet.' => '还没有消息.',
];
