<?php
return array (
  'Messages' => '消息',
  'New message' => '新消息',
  'Show all messages' => '显示所有的信息',
);
