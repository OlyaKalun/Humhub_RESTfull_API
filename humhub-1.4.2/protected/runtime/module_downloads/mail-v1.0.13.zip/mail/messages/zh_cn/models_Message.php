<?php
return array (
  'New message from {senderName}' => '来自 {senderName} 的新消息',
  'and {counter} other users' => '其他 {counter} 个用户',
);
