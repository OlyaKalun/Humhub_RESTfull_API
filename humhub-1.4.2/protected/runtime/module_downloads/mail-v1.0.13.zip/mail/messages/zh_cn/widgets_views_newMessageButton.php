<?php
return array (
  'New message' => '新消息',
  'Send message' => '发送消息',
);
