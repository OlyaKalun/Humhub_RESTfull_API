<?php

return [
    'Add recipients' => '',
    'New message' => 'Nou missatge',
    'Send' => 'Envia',
];
