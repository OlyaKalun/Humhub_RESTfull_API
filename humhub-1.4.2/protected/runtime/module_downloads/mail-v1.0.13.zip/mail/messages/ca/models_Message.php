<?php
return array (
  'New message from {senderName}' => 'Nou missatge de {senderName}',
  'and {counter} other users' => 'i {counter} membres més',
);
