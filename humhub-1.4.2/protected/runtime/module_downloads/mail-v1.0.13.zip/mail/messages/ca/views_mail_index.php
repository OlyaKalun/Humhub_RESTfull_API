<?php

return [
    'Conversations' => '',
    'New' => 'Nou',
    'There are no messages yet.' => 'No tens cap missatge.',
];
