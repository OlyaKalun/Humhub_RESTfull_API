<?php
return array (
  'Messages' => 'Pesan',
  'New message' => '',
  'Show all messages' => '',
);
